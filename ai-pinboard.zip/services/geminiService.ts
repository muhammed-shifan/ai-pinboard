import { GoogleGenAI, Modality } from "@google/genai";
import type { GenerationOptions } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

const parseRetryAfter = (error: any): number | null => {
  if (error && typeof error.message === 'string') {
    try {
      const errorBody = JSON.parse(error.message);
      if (errorBody.error?.status === 'RESOURCE_EXHAUSTED' || errorBody.error?.code === 429) {
        const details = errorBody.error?.details;
        if (Array.isArray(details)) {
          for (const detail of details) {
            if (detail['@type'] === 'type.googleapis.com/google.rpc.RetryInfo' && detail.retryDelay) {
              const retryDelay = detail.retryDelay;
              if (typeof retryDelay === 'string') {
                const seconds = parseInt(retryDelay.replace('s', ''), 10);
                if (!isNaN(seconds)) {
                  return seconds * 1000;
                }
              }
            }
          }
        }
      }
    } catch (e) {
      // Not a JSON error message, proceed with default backoff
    }
  }
  return null;
}


export const generateImage = async (options: GenerationOptions): Promise<string> => {
  const { prompt, model, aspectRatio, style, baseImage } = options;
  const MAX_RETRIES = 3;
  let lastError: Error = new Error("Unknown error during image generation");

  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      let finalPrompt = prompt;
      if (style) {
          finalPrompt = `${prompt}, in a ${style} style`;
      }
    
      if (baseImage) {
        if (!baseImage.startsWith('data:')) {
          throw new Error("Invalid base image format. Must be a data URL.");
        }
        const [meta, base64Data] = baseImage.split(',');
        if (!base64Data) {
          throw new Error("Invalid data URL for base image.");
        }
        const mimeType = meta.match(/:(.*?);/)?.[1] || 'image/png';

        const imagePart = { inlineData: { data: base64Data, mimeType } };
        const textPart = { text: finalPrompt };
  
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image', // Editing requires this model
          contents: { parts: [imagePart, textPart] },
          config: {
            responseModalities: [Modality.IMAGE],
          },
        });
  
        const part = response.candidates?.[0]?.content?.parts?.[0];
        if (part && part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const responseMimeType = part.inlineData.mimeType || 'image/png';
          return `data:${responseMimeType};base64,${base64ImageBytes}`;
        } else {
          console.error("No image data found in Gemini Flash API response for editing", response);
          throw new Error("No image generated from the Gemini Flash API for editing.");
        }
      } else if (model === 'imagen-4.0-generate-001') {
        const response = await ai.models.generateImages({
          model: 'imagen-4.0-generate-001',
          prompt: finalPrompt,
          config: {
            numberOfImages: 1,
            outputMimeType: 'image/png',
            aspectRatio: aspectRatio,
          },
        });
        
        const base64ImageBytes = response.generatedImages?.[0]?.image?.imageBytes;
        if (base64ImageBytes) {
          return `data:image/png;base64,${base64ImageBytes}`;
        } else {
          console.error("No image data found in Imagen API response", response);
          throw new Error("No image generated from the Imagen API.");
        }
      } else { // default to gemini-2.5-flash-image
        const aspectRatioHint = aspectRatio === '1:1' ? ', square image' : aspectRatio === '9:16' ? ', portrait aspect ratio' : ', landscape aspect ratio';
        const promptWithHint = finalPrompt + aspectRatioHint;
  
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: promptWithHint }],
          },
          config: {
            responseModalities: [Modality.IMAGE],
          },
        });
  
        const part = response.candidates?.[0]?.content?.parts?.[0];
        if (part && part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const mimeType = part.inlineData.mimeType || 'image/png';
          return `data:${mimeType};base64,${base64ImageBytes}`;
        } else {
          console.error("No image data found in Gemini Flash API response", response);
          throw new Error("No image generated from the Gemini Flash API.");
        }
      }
    } catch (error: any) {
        lastError = error;
        console.warn(`Attempt ${attempt + 1} failed for prompt: "${prompt}"`, error.message);
        
        if (attempt + 1 >= MAX_RETRIES) {
            break; // Don't delay after the last attempt
        }

        const retryAfter = parseRetryAfter(error);
        if (retryAfter !== null) {
            console.log(`Rate limit hit. Retrying after ${retryAfter + 500}ms...`);
            await delay(retryAfter + 500); // Add a small buffer
        } else {
            const delayTime = Math.pow(2, attempt) * 1000 + Math.random() * 1000;
            console.log(`Not a rate limit error or cannot parse delay. Retrying with exponential backoff: ${Math.round(delayTime)}ms...`);
            await delay(delayTime);
        }
    }
  }

  console.error(`Failed to generate image after ${MAX_RETRIES} attempts for prompt: "${prompt}"`, lastError);
  throw new Error("Failed to generate image. Please try again.");
};