import React, { useState } from 'react';
import type { Pin as PinType } from '../types';

type FilterType = 'none' | 'grayscale' | 'sepia' | 'blur-sm';

const FilterButton: React.FC<{ label: string; isActive: boolean; onClick: (e: React.MouseEvent) => void }> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-2 py-1 text-xs font-semibold rounded-full transition-colors ${isActive ? 'bg-red-600 text-white' : 'bg-black bg-opacity-50 text-white hover:bg-opacity-70'}`}
    >
        {label}
    </button>
);

export const Pin: React.FC<PinProps> = ({ pin, isSaved, onClick, onSaveClick: providedOnSaveClick }) => {
    
  const [filter, setFilter] = useState<FilterType>('none');
    
  const handleSaveClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    providedOnSaveClick(e);
  };

  const handleFilterClick = (e: React.MouseEvent, newFilter: FilterType) => {
    e.stopPropagation();
    setFilter(current => current === newFilter ? 'none' : newFilter);
  };

  const filterClasses: Record<FilterType, string> = {
      none: '',
      grayscale: 'grayscale',
      sepia: 'sepia',
      'blur-sm': 'blur-sm',
  };
    
  return (
    <div 
      className="relative group cursor-zoom-in break-inside-avoid bg-gray-200 rounded-lg shadow-md overflow-hidden" 
      onClick={onClick}
    >
      <img
        src={pin.imageUrl}
        alt={pin.prompt}
        className={`w-full h-full object-cover transition-all duration-300 ${filterClasses[filter]}`}
        style={{ aspectRatio: `${pin.width}/${pin.height}` }}
      />
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 rounded-lg transition-all duration-300 flex flex-col justify-between p-2">
        {/* Save Button Area */}
        <div className="flex justify-end">
            <button
                onClick={handleSaveClick}
                className={`font-bold py-2 px-4 rounded-full transition-all duration-300 text-sm md:text-base
                    ${isSaved ? 'bg-gray-800 text-white' : 'bg-red-600 text-white opacity-0 group-hover:opacity-100 hover:bg-red-700'}`}
            >
                {isSaved ? 'Saved' : 'Save'}
            </button>
        </div>

        {/* Filter Controls Area */}
        <div className="flex justify-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pb-1">
            <FilterButton label="Gray" isActive={filter === 'grayscale'} onClick={(e) => handleFilterClick(e, 'grayscale')} />
            <FilterButton label="Sepia" isActive={filter === 'sepia'} onClick={(e) => handleFilterClick(e, 'sepia')} />
            <FilterButton label="Blur" isActive={filter === 'blur-sm'} onClick={(e) => handleFilterClick(e, 'blur-sm')} />
        </div>
      </div>
    </div>
  );
};

interface PinProps {
    pin: PinType;
    isSaved: boolean;
    onClick: () => void;
    onSaveClick: (e: React.MouseEvent) => void;
  }
