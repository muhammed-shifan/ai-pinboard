import React, { useState, useRef, useEffect } from 'react';
import { CloseIcon } from './icons/CloseIcon';
import type { GenerationOptions, GenerationModel, AspectRatio, Style, UploadedPinData, Pin } from '../types';
import { STYLES } from '../types';

const AspectRatioSquareIcon: React.FC = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-6 h-6">
        <rect x="4" y="4" width="16" height="16" rx="2" stroke="currentColor" strokeWidth="2"/>
    </svg>
);
const AspectRatioPortraitIcon: React.FC = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-6 h-6">
        <rect x="7" y="2" width="10" height="20" rx="2" stroke="currentColor" strokeWidth="2"/>
    </svg>
);
const AspectRatioLandscapeIcon: React.FC = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-6 h-6">
        <rect x="2" y="7" width="20" height="10" rx="2" stroke="currentColor" strokeWidth="2"/>
    </svg>
);
const UploadIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1">
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);


interface GeneratePinFormProps {
  isGenerating: boolean;
  onGenerate: (options: GenerationOptions) => void;
  onUpload: (data: UploadedPinData) => void;
  onClose: () => void;
  pinToRemix?: Pin | null;
}

export const GeneratePinForm: React.FC<GeneratePinFormProps> = ({ isGenerating, onGenerate, onUpload, onClose, pinToRemix }) => {
  const [mode, setMode] = useState<'generate' | 'upload'>('generate');
  
  // Common state
  const [prompt, setPrompt] = useState('');

  // Generation state
  const [model, setModel] = useState<GenerationModel>('gemini-2.5-flash-image');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [style, setStyle] = useState<Style | null>(null);
  const [baseImage, setBaseImage] = useState<{ data: string; name: string; } | null>(null);

  // Upload state
  const [uploadedImage, setUploadedImage] = useState<{ data: string; width: number; height: number; name: string; } | null>(null);
  const [isProcessingUpload, setIsProcessingUpload] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isRemixing = !!pinToRemix;

  useEffect(() => {
    if (pinToRemix) {
      setMode('generate');
      setModel('gemini-2.5-flash-image');
      
      const { width, height } = pinToRemix;
      if (width > height * 1.2) setAspectRatio('16:9');
      else if (height > width * 1.2) setAspectRatio('9:16');
      else setAspectRatio('1:1');

      setPrompt('');
      setStyle(null);
      setBaseImage({ data: pinToRemix.imageUrl, name: `remix-of-${pinToRemix.id.substring(0,6)}.png` });
      setUploadedImage(null);
    }
  }, [pinToRemix]);

  const handleFileChange = (files: FileList | null) => {
    const file = files?.[0];
    if (file && file.type.startsWith('image/')) {
        setIsProcessingUpload(true);
        const reader = new FileReader();
        reader.onload = (event) => {
            const dataUrl = event.target?.result as string;
            const img = new Image();
            img.onload = () => {
                setUploadedImage({
                    data: dataUrl,
                    width: img.width,
                    height: img.height,
                    name: file.name
                });
                setIsProcessingUpload(false);
            };
            img.onerror = () => {
                alert('There was an error processing the image file.');
                setIsProcessingUpload(false);
            };
            img.src = dataUrl;
        };
        reader.onerror = () => {
            alert('There was an error reading the file.');
            setIsProcessingUpload(false);
        }
        reader.readAsDataURL(file);
    } else if (file) {
        alert('Please select a valid image file.');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handleFileChange(e.dataTransfer.files);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isGenerating || isProcessingUpload) return;

    if (mode === 'generate' && prompt.trim()) {
      onGenerate({ 
        prompt: prompt,
        model, 
        aspectRatio, 
        style: style ?? undefined,
        baseImage: baseImage ? baseImage.data : undefined,
      });
    } else if (mode === 'upload' && uploadedImage && prompt.trim()) {
        onUpload({
            imageUrl: uploadedImage.data,
            prompt,
            width: uploadedImage.width,
            height: uploadedImage.height,
        });
    }
  };
  
  const getTabClass = (tabMode: typeof mode) => mode === tabMode ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200';
  const isSubmitDisabled = mode === 'generate' ? (isGenerating || !prompt.trim()) : (isProcessingUpload || !prompt.trim() || !uploadedImage);
  const submitButtonText = mode === 'generate' 
    ? (isGenerating ? (isRemixing ? 'Remixing...' : 'Generating...') : (isRemixing ? 'Remix' : 'Generate')) 
    : (isProcessingUpload ? 'Processing...' : 'Create Pin');

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex justify-center items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-8 relative overflow-y-auto max-h-[95vh]" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600" aria-label="Close">
          <CloseIcon />
        </button>
        
        {!isRemixing && (
          <div className="flex justify-center mb-6">
              <div className="flex p-1 bg-gray-100 rounded-full">
                  <button onClick={() => setMode('generate')} className={`px-6 py-2 text-sm font-semibold rounded-full transition-colors ${getTabClass('generate')}`}>Generate</button>
                  <button onClick={() => setMode('upload')} className={`px-6 py-2 text-sm font-semibold rounded-full transition-colors ${getTabClass('upload')}`}>Upload</button>
              </div>
          </div>
        )}

        <h2 className="text-2xl font-bold text-center mb-6">{isRemixing ? 'Remix this Pin' : (mode === 'generate' ? 'Create your idea' : 'Upload your Pin')}</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'upload' && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Image</label>
                    <div
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                        onClick={() => !uploadedImage && !isProcessingUpload && fileInputRef.current?.click()}
                        className={`border-2 border-dashed border-gray-300 rounded-lg p-6 text-center transition-colors ${!uploadedImage && !isProcessingUpload ? 'cursor-pointer hover:border-red-500' : ''}`}
                    >
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={(e) => handleFileChange(e.target.files)}
                            className="hidden"
                            accept="image/*"
                        />
                        {isProcessingUpload ? (
                             <div className="flex flex-col items-center justify-center h-48">
                                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-red-500 mb-2"></div>
                                <p className="text-sm text-gray-500">Processing...</p>
                            </div>
                        ) : uploadedImage ? (
                            <div className="relative w-full text-center">
                                <div className="relative inline-block group">
                                     <div 
                                        className="cursor-pointer"
                                        onClick={() => fileInputRef.current?.click()}
                                     >
                                        <img src={uploadedImage.data} alt="Upload preview" className="max-h-48 mx-auto rounded-md shadow-sm" />
                                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 rounded-md transition-all flex items-center justify-center">
                                            <p className="text-white font-bold opacity-0 group-hover:opacity-100 transition-opacity text-sm">Change Image</p>
                                        </div>
                                    </div>
                                    <button 
                                        type="button" 
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setUploadedImage(null);
                                            if (fileInputRef.current) {
                                                fileInputRef.current.value = "";
                                            }
                                        }}
                                        className="absolute top-0 right-0 -mt-2 -mr-2 bg-white text-gray-700 rounded-full p-1 shadow-md hover:bg-gray-200 transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                                        aria-label="Remove image"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </button>
                                </div>
                                <p className="text-sm text-gray-800 mt-2 truncate font-medium">{uploadedImage.name}</p>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-48">
                                <UploadIcon />
                                <p className="mt-2 text-sm text-gray-600">Drag & drop or click to upload</p>
                                <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

          {mode === 'generate' && baseImage && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Remixing Image</label>
                    <div className="relative rounded-lg overflow-hidden border">
                        <img src={baseImage.data} alt="Remix source" className="w-full h-auto object-contain max-h-48" />
                    </div>
                </div>
            )}

          <div>
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">
              {isRemixing ? 'Describe your edit' : 'Prompt / Description'}
            </label>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={isRemixing ? "e.g., Add a futuristic city in the background" : (mode === 'generate' ? "e.g., A majestic lion wearing a crown..." : "e.g., My trip to the mountains...")}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-shadow"
              rows={3}
              required
            />
          </div>

          {mode === 'generate' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                <div className={`grid grid-cols-2 gap-2 ${isRemixing ? 'opacity-50' : ''}`}>
                  {[
                    { id: 'gemini-2.5-flash-image', label: '⚡️ Fast', description: 'Good for quick ideas.' },
                    { id: 'imagen-4.0-generate-001', label: '✨ High Quality', description: 'Best for final images.' },
                  ].map((opt) => (
                    <button type="button" key={opt.id} onClick={() => !isRemixing && setModel(opt.id as GenerationModel)}
                      className={`p-3 border rounded-lg text-left transition-all ${model === opt.id ? 'bg-red-50 border-red-500 ring-2 ring-red-500' : 'bg-white border-gray-300 hover:border-gray-400'} ${isRemixing ? 'cursor-not-allowed' : ''}`}
                      disabled={isRemixing}
                    >
                      <p className="font-semibold">{opt.label}</p>
                      <p className="text-xs text-gray-500">{opt.description}</p>
                    </button>
                  ))}
                </div>
                {isRemixing && <p className="text-xs text-gray-500 mt-1">Image remixing uses the Fast model.</p>}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Aspect Ratio</label>
                <div className={`grid grid-cols-3 gap-2 ${isRemixing ? 'opacity-50' : ''}`}>
                     {[
                        { id: '1:1', icon: <AspectRatioSquareIcon />, label: 'Square' },
                        { id: '9:16', icon: <AspectRatioPortraitIcon />, label: 'Portrait' },
                        { id: '16:9', icon: <AspectRatioLandscapeIcon />, label: 'Landscape' },
                    ].map((opt) => (
                         <button type="button" key={opt.id} onClick={() => !isRemixing && setAspectRatio(opt.id as AspectRatio)}
                            className={`flex flex-col items-center justify-center p-3 border rounded-lg transition-colors ${aspectRatio === opt.id ? 'border-red-500 text-red-600' : 'border-gray-300 text-gray-500 hover:border-gray-400 hover:text-gray-700'} ${isRemixing ? 'cursor-not-allowed' : ''}`}
                            disabled={isRemixing}
                         >
                             {opt.icon}
                             <span className="text-sm mt-1">{opt.label}</span>
                         </button>
                     ))}
                </div>
                 {isRemixing && <p className="text-xs text-gray-500 mt-1">Aspect ratio is locked to the original image.</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Style (optional)</label>
                <div className="flex flex-wrap gap-2">
                    {STYLES.map(s => (
                        <button type="button" key={s} onClick={() => setStyle(prev => prev === s ? null : s)}
                          className={`px-3 py-1 text-sm font-medium rounded-full border transition-colors ${style === s ? 'bg-red-600 text-white border-red-600' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-100'}`}
                        >
                            {s}
                        </button>
                    ))}
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={isSubmitDisabled}
            className="w-full bg-red-600 text-white font-bold py-3 px-4 rounded-full hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
          >
            {(isGenerating || isProcessingUpload) && (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
            )}
            {submitButtonText}
          </button>
        </form>
      </div>
    </div>
  );
};
