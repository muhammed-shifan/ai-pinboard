
import React from 'react';
import { Pin as PinComponent } from './Pin';
import type { Pin } from '../types';

interface MasonryGridProps {
  pins: Pin[];
  savedPinIds: Set<string>;
  onPinClick: (pin: Pin) => void;
  onSaveClick: (pinId: string) => void;
}

export const MasonryGrid: React.FC<MasonryGridProps> = ({ pins, savedPinIds, onPinClick, onSaveClick }) => {
  if (pins.length === 0) {
    return null;
  }
  
  return (
    <div
      className="columns-2 md:columns-3 lg:columns-4 xl:columns-5 2xl:columns-6 gap-4 space-y-4"
    >
      {pins.map((pin) => (
        <PinComponent
          key={pin.id}
          pin={pin}
          isSaved={savedPinIds.has(pin.id)}
          onClick={() => onPinClick(pin)}
          onSaveClick={() => onSaveClick(pin.id)}
        />
      ))}
    </div>
  );
};
