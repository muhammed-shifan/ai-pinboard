
import React, { useState, useRef, useEffect } from 'react';
import { SearchIcon } from './icons/SearchIcon';
import { UserIcon } from './icons/UserIcon';

interface HeaderProps {
  searchTerm: string;
  onSearchChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onNavigate: (view: 'home' | 'profile') => void;
  currentView: 'home' | 'profile';
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ searchTerm, onSearchChange, onNavigate, currentView, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const getButtonClass = (view: 'home' ) => {
    return currentView === view
      ? 'bg-gray-800 text-white'
      : 'bg-white text-gray-800 hover:bg-gray-100';
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-md p-4 z-50 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <a href="#" className="flex items-center space-x-2" onClick={(e) => { e.preventDefault(); onNavigate('home'); }}>
          <svg className="w-8 h-8 text-red-600" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M24 4C12.9543 4 4 12.9543 4 24C4 32.2263 9.03434 39.3134 16.5 42.4457V29.5H12V24.5H16.5V20.5C16.5 16.0898 19.0196 14 22.8125 14C24.625 14 26.1562 14.2812 26.625 14.3438V18.8125H24.2188C22.1875 18.8125 21.5 20.0625 21.5 21.5V24.5H26.5L25.5 29.5H21.5V43.5312C29.6231 42.2272 35.5 35.8164 35.5 28C35.5 15.0117 24 4 24 4Z" fill="#E60023"/>
          </svg>
          <span className="text-xl font-bold hidden md:block">AI Pinboard</span>
        </a>
        <nav className="flex items-center space-x-2">
          <button onClick={() => onNavigate('home')} className={`font-semibold px-4 py-2 rounded-full transition-colors duration-200 ${getButtonClass('home')}`}>
            Home
          </button>
        </nav>
      </div>

      <div className="flex-1 max-w-2xl mx-4">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon />
          </div>
          <input
            type="search"
            placeholder="Search by prompt..."
            value={searchTerm}
            onChange={onSearchChange}
            className="w-full bg-gray-100 border border-transparent focus:ring-2 focus:ring-red-500 focus:bg-white focus:border-transparent rounded-full py-2 pl-10 pr-4"
          />
        </div>
      </div>
      
      <div className="flex items-center relative" ref={menuRef}>
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className={`p-2 rounded-full transition-colors duration-200 ${currentView === 'profile' || isMenuOpen ? 'bg-gray-200' : 'hover:bg-gray-100'}`}
          aria-label="User Menu"
          aria-haspopup="true"
          aria-expanded={isMenuOpen}
        >
          <UserIcon />
        </button>
        {isMenuOpen && (
            <div className="absolute top-full right-0 mt-2 w-48 bg-white rounded-lg shadow-xl py-2 z-10 ring-1 ring-black ring-opacity-5">
                <button
                    onClick={() => { onNavigate('profile'); setIsMenuOpen(false); }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                    Profile
                </button>
                <button
                    onClick={() => { onLogout(); setIsMenuOpen(false); }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                    Sign Out
                </button>
            </div>
        )}
      </div>
    </header>
  );
};
