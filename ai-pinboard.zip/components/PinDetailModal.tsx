import React from 'react';
import type { Pin } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { ShareIcon } from './icons/ShareIcon';
import { RemixIcon } from './icons/RemixIcon';

interface PinDetailModalProps {
  pin: Pin;
  isSaved: boolean;
  onClose: () => void;
  onSaveClick: (pinId: string) => void;
  onRemixClick: (pin: Pin) => void;
}

// Helper function to convert data URL to File object
const dataUrlToFile = async (dataUrl: string, fileName: string): Promise<File | null> => {
    try {
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      return new File([blob], fileName, { type: blob.type });
    } catch (error) {
      console.error("Error converting data URL to File:", error);
      return null;
    }
};


export const PinDetailModal: React.FC<PinDetailModalProps> = ({ pin, isSaved, onClose, onSaveClick, onRemixClick }) => {
  const handleShare = async () => {
    const fileName = `ai-pinboard-${pin.id.substring(0, 8)}.png`;
    const file = await dataUrlToFile(pin.imageUrl, fileName);
    
    const shareData: ShareData = {
      title: 'AI Pinboard Creation',
      text: `Check out this AI-generated image! Prompt: "${pin.prompt}"`,
      files: file ? [file] : undefined,
    };
  
    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        console.error('Error sharing:', error);
        alert("Sharing was cancelled or failed.");
      }
    } else {
      // Fallback for browsers that don't support Web Share API for files
      try {
        await navigator.clipboard.writeText(`Check out this AI-generated image! Prompt: "${pin.prompt}"`);
        alert('Prompt copied to clipboard! You can now download the image to share it.');
      } catch (err) {
        alert('This browser does not support sharing. Please copy the prompt and download the image manually.');
      }
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-70 z-[100] flex justify-center items-center p-4" 
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col md:flex-row overflow-hidden" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full md:w-1/2 bg-gray-100 flex items-center justify-center">
            <img src={pin.imageUrl} alt={pin.prompt} className="w-full h-auto object-contain max-h-[90vh]" />
        </div>
        <div className="w-full md:w-1/2 p-6 flex flex-col">
            <div className="flex justify-end mb-4">
                <button
                    onClick={onClose}
                    className="text-gray-500 hover:text-gray-800"
                    aria-label="Close"
                >
                    <CloseIcon />
                </button>
            </div>
            <div className="flex-grow overflow-y-auto pr-2">
                <h2 className="text-2xl font-bold mb-4">Generated Pin</h2>
                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                    <h3 className="text-sm font-semibold text-gray-500 mb-1">PROMPT</h3>
                    <p className="text-gray-800 break-words">{pin.prompt}</p>
                </div>
                 <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                        onClick={() => onRemixClick(pin)}
                        className="flex items-center justify-center w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 px-4 rounded-full transition-colors"
                        aria-label="Remix this image"
                    >
                        <RemixIcon />
                        <span className="ml-2">Remix</span>
                    </button>
                     <button
                        onClick={handleShare}
                        className="flex items-center justify-center w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 px-4 rounded-full transition-colors"
                        aria-label="Share image"
                    >
                        <ShareIcon />
                        <span className="ml-2">Share</span>
                    </button>
                    <a
                        href={pin.imageUrl}
                        download={`ai-pinboard-${pin.id.substring(0, 8)}.jpg`}
                        className="flex items-center justify-center w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold py-3 px-4 rounded-full transition-colors"
                        aria-label="Download image"
                    >
                        <DownloadIcon />
                        <span className="ml-2">Download</span>
                    </a>
                 </div>
            </div>
            <div className="mt-6 flex-shrink-0">
                <button
                    onClick={() => onSaveClick(pin.id)}
                    className={`w-full font-bold py-3 px-6 rounded-full text-lg transition-colors duration-200
                        ${isSaved ? 'bg-gray-800 text-white' : 'bg-red-600 text-white hover:bg-red-700'}`}
                >
                    {isSaved ? 'Saved' : 'Save'}
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
