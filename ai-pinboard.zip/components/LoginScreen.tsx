import React from 'react';
import { GoogleIcon } from './icons/GoogleIcon';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  return (
    <div className="fixed inset-0 bg-gray-50 z-[200] flex flex-col items-center justify-center p-4">
      <div className="text-center w-full max-w-sm">
        <div className="flex justify-center items-center space-x-3 mb-4">
            <svg className="w-12 h-12 text-red-600" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 4C12.9543 4 4 12.9543 4 24C4 32.2263 9.03434 39.3134 16.5 42.4457V29.5H12V24.5H16.5V20.5C16.5 16.0898 19.0196 14 22.8125 14C24.625 14 26.1562 14.2812 26.625 14.3438V18.8125H24.2188C22.1875 18.8125 21.5 20.0625 21.5 21.5V24.5H26.5L25.5 29.5H21.5V43.5312C29.6231 42.2272 35.5 35.8164 35.5 28C35.5 15.0117 24 4 24 4Z" fill="#E60023"/>
            </svg>
            <h1 className="text-4xl font-bold text-gray-800">AI Pinboard</h1>
        </div>
        <p className="text-gray-600 mb-10 text-lg">Visual discovery with the power of AI.</p>
        
        <button
          onClick={onLogin}
          className="w-full flex items-center justify-center bg-white border border-gray-300 text-gray-700 font-semibold py-3 px-4 rounded-full shadow-sm hover:bg-gray-50 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
        >
          <GoogleIcon />
          <span className="ml-3">Sign in with Google</span>
        </button>

        <p className="text-xs text-gray-400 mt-8">
            By continuing, you agree to AI Pinboard's Terms of Service and acknowledge you've read our Privacy Policy.
        </p>
      </div>
    </div>
  );
};
