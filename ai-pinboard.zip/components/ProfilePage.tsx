import React, { useState } from 'react';
import { MasonryGrid } from './MasonryGrid';
import type { Pin } from '../types';

interface ProfilePageProps {
  createdPins: Pin[];
  savedPins: Pin[];
  savedPinIds: Set<string>;
  onPinClick: (pin: Pin) => void;
  onSaveClick: (pinId: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  createdPins,
  savedPins,
  savedPinIds,
  onPinClick,
  onSaveClick,
}) => {
  const [activeTab, setActiveTab] = useState<'created' | 'saved'>('created');

  const pinsToShow = activeTab === 'created' ? createdPins : savedPins;

  const getTabClass = (tab: 'created' | 'saved') => {
    return activeTab === tab
      ? 'border-b-2 border-gray-800 text-gray-800'
      : 'text-gray-500 hover:text-gray-800';
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col items-center mb-8">
        <div className="w-24 h-24 bg-gray-200 rounded-full mb-4 flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </div>
        <h1 className="text-3xl font-bold">Alex Doe</h1>
        <p className="text-gray-500 mt-1">alex.doe@example.com</p>
        <p className="text-gray-500 text-sm mt-2">Your collection of created and saved pins.</p>
      </div>

      <div className="flex justify-center border-b mb-8">
        <button
          onClick={() => setActiveTab('created')}
          className={`px-6 py-3 font-semibold text-lg transition-colors ${getTabClass('created')}`}
        >
          Created
        </button>
        <button
          onClick={() => setActiveTab('saved')}
          className={`px-6 py-3 font-semibold text-lg transition-colors ${getTabClass('saved')}`}
        >
          Saved
        </button>
      </div>

      {pinsToShow.length > 0 ? (
        <MasonryGrid
          pins={pinsToShow}
          savedPinIds={savedPinIds}
          onPinClick={onPinClick}
          onSaveClick={onSaveClick}
        />
      ) : (
        <div className="text-center py-20 text-gray-500">
          <h2 className="text-2xl font-semibold">
            {activeTab === 'created' ? "You haven't created any pins yet." : "You haven't saved any pins yet."}
          </h2>
          <p>
            {activeTab === 'created' ? "Click the '+' button to bring your ideas to life!" : "Start exploring and save what inspires you!"}
          </p>
        </div>
      )}
    </div>
  );
};
