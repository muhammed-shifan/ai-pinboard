import { useState, useEffect, useCallback } from 'react';
import { generateImage } from '../services/geminiService';
import type { Pin, GenerationOptions, AspectRatio, UploadedPinData } from '../types';

const INITIAL_PROMPTS = [
  // Existing
  "A majestic lion wearing a crown, studio lighting",
  "A cozy library in a treehouse, raining outside",
  "Synthwave sunset over a retro-futuristic city",
  "A detailed watercolor of a fox in a snowy forest",
  "A vintage car on a coastal highway at dusk",
  "An astronaut playing guitar on the moon, with Earth in the background",
  "A magical forest with glowing mushrooms and fireflies",
  "A steampunk owl with intricate gears and brass details",
  "A tranquil Japanese garden with a koi pond and cherry blossoms",
  "A delicious-looking stack of pancakes with syrup and berries",
  "A surreal desert landscape with floating islands and giant crystals",
  "Bioluminescent jellyfish gracefully swimming in the deep dark ocean",
  "An elaborate medieval castle on a mountain peak at sunrise",
  "A cyberpunk alleyway at night, neon signs reflecting in puddles",
  "Portrait of a beautiful fantasy elf with intricate silver armor",
  "A robot tending to a vibrant rooftop garden in a futuristic metropolis",
  "An impressionist painting of a bustling Parisian street cafe",
  "A close-up shot of a hummingbird sipping nectar from a vibrant flower",
  "A whimsical illustration of animals having a tea party in the woods",
  "A minimalist abstract artwork representing 'serenity'",
  // New Nature & Environment
  "The Northern Lights over a frozen fjord in Norway, photorealistic",
  "A vibrant coral reef teeming with exotic fish, underwater photography",
  "An ancient, moss-covered redwood forest with sunbeams filtering through",
  "A dramatic volcanic eruption at night, cinematic",
  "A serene mountain lake reflecting a starry night sky, long exposure",
  "Eco-futuristic city with buildings covered in vertical gardens and solar panels",
  "A field of sunflowers at golden hour, Van Gogh style",
  "A powerful polar bear on an ice floe, arctic environment",
  "A macro photo of a dewdrop on a blade of grass, showing a refracted world",
  "An enchanted waterfall cascading into a hidden grotto, fantasy art",
  // New Architecture & Interior
  "A minimalist modern home made of glass and concrete in a forest setting",
  "The intricate details of a Gothic cathedral's ceiling",
  "A cozy, cluttered artist's studio with canvases and paint everywhere",
  "A futuristic skyscraper that pierces the clouds, 3D render",
  "A charming, ivy-covered cottage in the English countryside",
  "A bustling Moroccan souk with colorful spices and textiles",
  "An abandoned Art Deco movie palace, hauntingly beautiful",
  // New Sci-Fi & Fantasy
  "A colossal spaceship entering the atmosphere of a jungle planet",
  "A knight in glowing magical armor facing a dragon",
  "An alien marketplace on a desert planet, with strange creatures and technology",
  "A sorceress casting a complex spell, energy swirling around her",
  "A floating city held aloft by giant crystals, anime style",
  // New Abstract & Style
  "A dynamic explosion of colorful powder, high-speed photography",
  "Geometric patterns in pastel colors, minimalist design",
  "A fluid abstract painting with gold leaf accents",
  "A glitch art portrait of a human face",
  // New Food & Fashion
  "An artfully arranged charcuterie board with a variety of cheeses, fruits, and meats",
  "A high fashion model wearing a dress made of flowing water",
  "A meticulously crafted cup of latte art",
  "A close-up of a designer handbag with intricate details",
];

const ASPECT_RATIOS: AspectRatio[] = ['1:1', '9:16', '16:9'];

const getRandomOptions = (count: number): GenerationOptions[] => {
  const shuffled = [...INITIAL_PROMPTS].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count).map(prompt => ({
    prompt,
    model: 'gemini-2.5-flash-image', // Keep initial load fast
    aspectRatio: ASPECT_RATIOS[Math.floor(Math.random() * ASPECT_RATIOS.length)],
  }));
};

const createPinObject = (imageUrl: string, prompt: string, width: number, height: number): Pin => {
  return {
    id: new Date().toISOString() + Math.random(),
    imageUrl,
    prompt,
    width,
    height,
  };
};

const getPinDimensions = (aspectRatio: AspectRatio): { width: number, height: number } => {
    const baseWidth = 500;
    let width = baseWidth;
    let height = baseWidth;

    if (aspectRatio === '9:16') {
        height = Math.round(baseWidth * (16 / 9));
    } else if (aspectRatio === '16:9') {
        height = Math.round(baseWidth * (9 / 16));
    }
    return { width, height };
}

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const generatePinsSequentially = async (
    optionsList: GenerationOptions[],
    onPinGenerated: (pin: Pin) => void
) => {
  for (const options of optionsList) {
    try {
      const imageUrl = await generateImage(options);
      const { width, height } = getPinDimensions(options.aspectRatio);
      const pin = createPinObject(imageUrl, options.prompt, width, height);
      onPinGenerated(pin);
      await delay(1500); 
    } catch (error) {
      console.error(`Skipping pin for prompt "${options.prompt}" due to error:`, error);
    }
  }
};

export const usePins = () => {
  const [pins, setPins] = useState<Pin[]>([]);
  const [savedPins, setSavedPins] = useState<Pin[]>([]);
  const [createdPins, setCreatedPins] = useState<Pin[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('savedPins');
      if (saved) setSavedPins(JSON.parse(saved));
      
      const created = localStorage.getItem('createdPins');
      if (created) setCreatedPins(JSON.parse(created));

    } catch (error) {
      console.error("Failed to load pins from localStorage", error);
    }

    const generateInitialPins = async () => {
        setIsLoading(true);
        setPins([]); 
        try {
            const options = getRandomOptions(5);
            await generatePinsSequentially(options, (newPin) => {
                setPins(prev => [...prev, newPin]);
            });
        } catch (error) {
            console.error("Failed to generate initial pins", error);
        } finally {
            setIsLoading(false);
        }
    };
    
    if (localStorage.getItem('isAuthenticated') === 'true') {
        generateInitialPins();
    } else {
        setIsLoading(false);
    }
  }, []);

  const persistCreatedPins = (pinsToSave: Pin[]) => {
      try {
        localStorage.setItem('createdPins', JSON.stringify(pinsToSave));
      } catch (error) {
        console.error("Failed to save created pins to localStorage", error);
      }
  };

  const generatePin = useCallback(async (options: GenerationOptions) => {
    setIsGenerating(true);
    try {
      const imageUrl = await generateImage(options);
      const { width, height } = getPinDimensions(options.aspectRatio);
      const newPin = createPinObject(imageUrl, options.prompt, width, height);
      
      setPins(prev => [newPin, ...prev]);
      setCreatedPins(prev => {
        const newCreated = [newPin, ...prev];
        persistCreatedPins(newCreated);
        return newCreated;
      });

    } catch (error) {
      console.error("Failed to generate a new pin:", error);
      alert("Sorry, there was an error generating your pin. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const uploadPin = useCallback(async (data: UploadedPinData) => {
      const newPin = createPinObject(data.imageUrl, data.prompt, data.width, data.height);
      setPins(prev => [newPin, ...prev]);
      setCreatedPins(prev => {
        const newCreated = [newPin, ...prev];
        persistCreatedPins(newCreated);
        return newCreated;
      });
  }, []);

  const loadMorePins = useCallback(async () => {
    if (isLoading || isGenerating) return;
    setIsLoading(true);
     try {
        const options = getRandomOptions(4);
        await generatePinsSequentially(options, (newPin) => {
            setPins(prev => [...prev, newPin]);
        });
    } catch (error) {
        console.error("Failed to load more pins", error);
    } finally {
        setIsLoading(false);
    }
  }, [isLoading, isGenerating]);

  const toggleSavePin = useCallback((pinId: string) => {
    setSavedPins(prevSavedPins => {
      const isAlreadySaved = prevSavedPins.some(p => p.id === pinId);
      let newSavedPins;
      if (isAlreadySaved) {
        newSavedPins = prevSavedPins.filter(p => p.id !== pinId);
      } else {
        const pinToSave = [...pins, ...savedPins, ...createdPins].find(p => p.id === pinId);
        if (pinToSave) {
          // Avoid duplicates if pin exists in multiple arrays
          const uniquePinToSave = { ...pinToSave };
          const existingIds = new Set(prevSavedPins.map(p => p.id));
          if (!existingIds.has(uniquePinToSave.id)) {
            newSavedPins = [uniquePinToSave, ...prevSavedPins];
          } else {
            return prevSavedPins;
          }
        } else {
            return prevSavedPins;
        }
      }
      try {
        localStorage.setItem('savedPins', JSON.stringify(newSavedPins));
      } catch (error) {
          console.error("Failed to save pins to localStorage", error);
      }
      return newSavedPins;
    });
  }, [pins, savedPins, createdPins]);

  return {
    pins,
    savedPins,
    createdPins,
    isLoading,
    isGenerating,
    generatePin,
    uploadPin,
    loadMorePins,
    toggleSavePin,
  };
};
